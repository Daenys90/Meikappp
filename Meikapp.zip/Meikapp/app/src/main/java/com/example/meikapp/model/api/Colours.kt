package com.example.meikapp.model.api

class Colours (
    val hex_value : String,
    val colour_name : String
)

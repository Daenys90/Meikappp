package com.example.meikapp.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.meikapp.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
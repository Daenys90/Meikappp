package com.example.meikapp.app

class RoomApplication {

}

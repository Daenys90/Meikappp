package com.example.meikapp.model.api

class Link(
    val image_link : String,
    val product_link : String,
    val website_link : String
)

